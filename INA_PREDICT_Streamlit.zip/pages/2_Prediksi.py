
import streamlit as st
import streamlit.components.v1 as components

html_content = r"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, viewport-fit=cover">
    <title>INA-PREDICT | Prediksi Bencana - AI Early Warning System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Space Grotesk', 'Inter', sans-serif; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
            min-height: 100vh;
            font-size: 15px;
            line-height: 1.45;
        }
        
        /* DARK MODE */
        body.dark { background: #0a0f0d; color: #e2e8e4; }
        body.dark .bg-gradient { background: radial-gradient(circle at 30% 20%, #14281f, #070b09); }
        body.dark .sidebar { background: rgba(6, 12, 10, 0.97); border-right-color: rgba(43, 110, 78, 0.4); backdrop-filter: blur(20px); }
        body.dark .stat-card, body.dark .glass-card, body.dark .pred-stat-card,
        body.dark .chart-box, body.dark .pred-day-card, body.dark .city-risk-card,
        body.dark .city-risk-section, body.dark .warning-card, body.dark .top-bar,
        body.dark .modal-content, body.dark .info-card { 
            background: rgba(18, 28, 23, 0.9); 
            border-color: rgba(43, 110, 78, 0.3); 
        }
        
        /* LIGHT MODE */
        body.light { background: #f0f4f1; color: #1a2c24; }
        body.light .bg-gradient { background: radial-gradient(circle at 30% 20%, #e2ece6, #d3e0d8); }
        body.light .sidebar { background: rgba(255, 255, 255, 0.97); border-right-color: rgba(43, 110, 78, 0.2); }
        body.light .stat-card, body.light .glass-card, body.light .pred-stat-card,
        body.light .chart-box, body.light .pred-day-card, body.light .city-risk-card,
        body.light .city-risk-section, body.light .warning-card, body.light .top-bar,
        body.light .modal-content, body.light .info-card { 
            background: rgba(255, 255, 255, 0.94); 
            border-color: rgba(43, 110, 78, 0.15); 
        }
        
        /* Warna Utama - Hijau Toska */
        .stat-value, .pred-stat-card .stat-value, .logo-text,
        .nav-link:hover, .nav-link.active, .pred-day-name, .card-header h3,
        .chart-box h4, .css-bar-label, .line-point-value {
            color: #2b6e4e !important;
        }
        
        body.dark .stat-value, body.dark .pred-stat-card .stat-value,
        body.dark .logo-text, body.dark .pred-day-name, body.dark .card-header h3,
        body.dark .chart-box h4, body.dark .css-bar-label, body.dark .line-point-value {
            color: #3d9b6d !important;
        }
        
        .alert-status, .ai-badge, .btn-modal, .status-badge {
            background: linear-gradient(135deg, #2b6e4e, #3d9b6d);
            color: white;
        }
        
        .bg-gradient { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -2; transition: all 0.3s; }
        
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: rgba(43, 110, 78, 0.1); border-radius: 10px; }
        ::-webkit-scrollbar-thumb { background: linear-gradient(135deg, #2b6e4e, #3d9b6d); border-radius: 10px; }
        
        /* SIDEBAR */
        .sidebar { width: 280px; padding: 32px 24px; position: fixed; height: 100vh; overflow-y: auto; z-index: 20; border-right: 1px solid; transition: all 0.3s ease; }
        .logo { display: flex; align-items: center; gap: 14px; margin-bottom: 48px; }
        .logo-icon { width: 52px; height: 52px; background: linear-gradient(135deg, #2b6e4e, #3d9b6d); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; color: white; box-shadow: 0 8px 20px rgba(43,110,78,0.3); }
        .logo-text { font-size: 1.4rem; font-weight: 700; letter-spacing: -0.5px; }
        .logo-small { font-size: 0.6rem; opacity: 0.65; letter-spacing: 1.5px; margin-top: 4px; color: inherit; }
        .nav-item { margin: 10px 0; }
        .nav-link { display: flex; align-items: center; gap: 14px; padding: 12px 18px; border-radius: 14px; font-weight: 600; font-size: 0.9rem; text-decoration: none; transition: all 0.2s; border-left: 3px solid transparent; cursor: pointer; }
        body.dark .nav-link { color: #b8d5c8; }
        body.light .nav-link { color: #4a6a5a; }
        .nav-link:hover, .nav-link.active { background: rgba(43, 110, 78, 0.12); color: #2b6e4e !important; border-left-color: #2b6e4e; transform: translateX(4px); }
        .theme-toggle { display: flex; align-items: center; justify-content: space-between; margin-top: 40px; padding: 12px 18px; background: rgba(43, 110, 78, 0.12); border-radius: 50px; cursor: pointer; font-weight: 500; font-size: 0.85rem; }
        .update-time { margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(43, 110, 78, 0.2); font-size: 0.6rem; text-align: center; opacity: 0.7; }
        
        /* MAIN CONTENT */
        .main-content { margin-left: 280px; padding: 24px 32px; transition: all 0.3s; }
        .top-bar { backdrop-filter: blur(16px); border-radius: 28px; padding: 18px 28px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 16px; border: 1px solid; }
        .top-bar h2 { font-size: 1.2rem; font-weight: 700; }
        .top-bar p { font-size: 0.7rem; opacity: 0.7; margin-top: 4px; }
        .alert-status { padding: 10px 28px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; cursor: pointer; animation: pulse 2s infinite; border: none; }
        @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(43, 110, 78, 0.5); } 50% { box-shadow: 0 0 0 8px rgba(43, 110, 78, 0); } }
        
        .prediction-hero { border-radius: 32px; padding: 30px; margin-bottom: 28px; text-align: center; border: 1px solid rgba(43, 110, 78, 0.3); background: linear-gradient(135deg, rgba(43, 110, 78, 0.1), rgba(43, 110, 78, 0.02)); }
        .prediction-hero h1 { font-size: 1.8rem; margin-bottom: 12px; color: #2b6e4e; }
        body.dark .prediction-hero h1 { color: #3d9b6d; }
        .ai-badge { display: inline-block; padding: 5px 18px; border-radius: 30px; font-size: 0.7rem; margin-top: 15px; font-weight: 600; }
        
        /* STATS ROW */
        .stats-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; margin-bottom: 28px; }
        .pred-stat-card { backdrop-filter: blur(12px); border-radius: 28px; padding: 20px 16px; text-align: center; cursor: pointer; transition: all 0.25s ease; border: 1px solid; position: relative; overflow: hidden; }
        .pred-stat-card::before { content: ''; position: absolute; top: 0; left: -100%; width: 100%; height: 100%; background: linear-gradient(90deg, transparent, rgba(43, 110, 78, 0.08), transparent); transition: 0.6s; }
        .pred-stat-card:hover::before { left: 100%; }
        .pred-stat-card:hover { transform: translateY(-6px); border-color: #2b6e4e !important; box-shadow: 0 12px 28px rgba(0,0,0,0.15); }
        .pred-stat-card .stat-icon { font-size: 2rem; margin-bottom: 10px; display: block; color: #2b6e4e; }
        body.dark .pred-stat-card .stat-icon { color: #3d9b6d; }
        .pred-stat-card .stat-value { font-size: 1.8rem; font-weight: 800; }
        .pred-stat-card .stat-label { font-size: 0.6rem; margin-top: 5px; opacity: 0.7; font-weight: 500; }
        
        /* GLASS CARD */
        .glass-card { backdrop-filter: blur(12px); border-radius: 32px; border: 1px solid; padding: 24px; transition: 0.3s; margin-bottom: 28px; }
        .glass-card:hover { border-color: rgba(43, 110, 78, 0.5); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid rgba(43, 110, 78, 0.2); padding-bottom: 14px; flex-wrap: wrap; gap: 10px; }
        .card-header h3 { font-size: 0.95rem; display: flex; align-items: center; gap: 8px; font-weight: 700; }
        
        /* VERTICAL LAYOUT */
        .two-columns { display: flex; flex-direction: column; gap: 28px; margin-bottom: 28px; }
        
        .weekly-prediction { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 10px; justify-content: space-between; }
        .pred-day-card { flex: 1; min-width: 95px; border-radius: 24px; padding: 15px 8px; text-align: center; cursor: pointer; transition: 0.2s; border: 1px solid rgba(43, 110, 78, 0.15); background: rgba(0,0,0,0.2); }
        .pred-day-card:hover { transform: translateY(-5px); border-color: #2b6e4e; background: rgba(43, 110, 78, 0.1); }
        .pred-day-name { font-size: 0.7rem; font-weight: 700; }
        .pred-date { font-size: 0.5rem; opacity: 0.6; margin: 5px 0; }
        .pred-risk { font-size: 1.1rem; font-weight: 800; margin: 8px 0; }
        .pred-risk.high { color: #e07a5f; }
        .pred-risk.medium { color: #e0a343; }
        .pred-risk.low { color: #3d9b6d; }
        .pred-status { font-size: 0.5rem; padding: 3px 8px; border-radius: 20px; display: inline-block; font-weight: 700; }
        .status-high { background: rgba(200, 80, 60, 0.2); color: #e07a5f; }
        .status-medium { background: rgba(220, 140, 40, 0.2); color: #e0a343; }
        .status-low { background: rgba(61, 155, 109, 0.2); color: #3d9b6d; }
        
        .province-risk-list { max-height: 380px; overflow-y: auto; }
        
        /* ========== DIPERBAIKI: Angka 92% di tengah atas garis MERAH ========== */
        .province-risk-item { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            padding: 14px 0; 
            border-bottom: 1px solid rgba(43, 110, 78, 0.1); 
            cursor: pointer; 
            transition: 0.2s; 
        }
        .province-risk-item:hover { 
            background: rgba(43, 110, 78, 0.08); 
            padding-left: 8px; 
            border-radius: 16px; 
        }
        .province-left {
            flex: 2;
        }
        .province-left strong {
            font-size: 0.85rem;
            display: block;
            margin-bottom: 4px;
        }
        .province-left span {
            font-size: 0.55rem;
            opacity: 0.7;
        }
        .province-right {
            flex-shrink: 0;
            width: 130px;
            text-align: center;
        }
        /* Angka persen di tengah, di atas garis */
        .province-percent {
            font-weight: 800;
            font-size: 1rem;
            margin-bottom: 8px;
            display: block;
            text-align: center;
        }
        /* GARIS PROGRESS - WARNA MERAH, PENDEK, DI TENGAH */
        .risk-bar {
            width: 100px;
            height: 8px;
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
            overflow: hidden;
            margin: 0 auto;
        }
        .risk-fill {
            height: 100%;
            border-radius: 10px;
        }
        /* WARNA MERAH UNTUK SEMUA GARIS */
        .risk-fill.high { background: linear-gradient(90deg, #e07a5f, #c25d45); }
        .risk-fill.medium { background: linear-gradient(90deg, #e07a5f, #c25d45); }
        .risk-fill.low { background: linear-gradient(90deg, #e07a5f, #c25d45); }
        /* ========== END ========== */
        
        .charts-container { display: flex; flex-direction: column; gap: 30px; }
        .chart-box { border-radius: 24px; padding: 24px; cursor: pointer; transition: 0.2s; border: 1px solid rgba(43, 110, 78, 0.15); background: rgba(0,0,0,0.2); width: 100%; }
        .chart-box:hover { border-color: #2b6e4e; transform: translateY(-3px); }
        .chart-box h4 { font-size: 0.8rem; margin-bottom: 20px; display: flex; align-items: center; gap: 8px; font-weight: 700; }
        
        /* GRAFIK BAR - LEGA */
        .css-bar-chart { 
            display: flex; 
            gap: 40px; 
            justify-content: center; 
            align-items: flex-end; 
            height: 240px; 
            padding: 16px 20px 8px 20px; 
            flex-wrap: wrap; 
        }
        .css-bar-item { 
            flex: 1; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            gap: 14px; 
            min-width: 80px; 
            margin: 0 8px;
        }
        .css-bar { 
            width: 100%; 
            max-width: 80px; 
            background: linear-gradient(180deg, #2b6e4e, #3d9b6d); 
            border-radius: 16px 16px 10px 10px; 
            transition: height 0.3s; 
            min-height: 24px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .css-bar-label { 
            font-size: 0.75rem; 
            text-align: center; 
            font-weight: 700; 
            letter-spacing: 0.5px;
        }
        .css-bar-value { 
            font-size: 0.7rem; 
            font-weight: 800; 
            opacity: 0.95; 
            margin-top: 6px;
            background: rgba(0,0,0,0.3);
            padding: 2px 10px;
            border-radius: 30px;
        }
        
        /* GRAFIK LINE - LEGA */
        .line-points { 
            display: flex; 
            justify-content: space-between; 
            margin-bottom: 16px; 
            flex-wrap: wrap; 
            gap: 16px; 
            padding: 12px 16px;
        }
        .line-point { 
            text-align: center; 
            flex: 1; 
            min-width: 72px; 
            padding: 10px 4px;
            background: rgba(43, 110, 78, 0.05);
            border-radius: 20px;
            transition: 0.2s;
        }
        .line-point:hover {
            background: rgba(43, 110, 78, 0.15);
            transform: translateY(-3px);
        }
        .line-point-value { 
            font-size: 0.9rem; 
            font-weight: 800; 
            background: linear-gradient(135deg, #2b6e4e20, #3d9b6d30);
            display: inline-block;
            padding: 6px 14px;
            border-radius: 40px;
            letter-spacing: 0.5px;
        }
        .line-point-label { 
            font-size: 0.65rem; 
            opacity: 0.8; 
            margin-top: 12px; 
            font-weight: 600;
        }
        
        .search-box { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
        .city-search, .filter-select { flex: 1; padding: 12px 18px; border-radius: 50px; border: 1px solid rgba(43, 110, 78, 0.3); background: rgba(0,0,0,0.04); font-size: 0.75rem; outline: none; font-weight: 500; }
        .city-search:focus, .filter-select:focus { border-color: #2b6e4e; }
        .city-risk-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px; max-height: 500px; overflow-y: auto; }
        .city-risk-card { border-radius: 20px; padding: 14px 16px; cursor: pointer; transition: 0.2s; border: 1px solid rgba(43, 110, 78, 0.15); background: rgba(0,0,0,0.2); }
        .city-risk-card:hover { transform: translateX(5px); border-color: #2b6e4e; background: rgba(43, 110, 78, 0.08); }
        .city-name-large { font-weight: 700; font-size: 0.85rem; display: flex; justify-content: space-between; align-items: center; }
        
        .warning-card { border-radius: 20px; padding: 14px; cursor: pointer; transition: 0.2s; border: 1px solid rgba(43, 110, 78, 0.15); margin-bottom: 12px; background: rgba(0,0,0,0.2); }
        .warning-card:hover { border-color: #2b6e4e; background: rgba(43, 110, 78, 0.08); transform: translateX(5px); }
        .info-card { border-radius: 20px; padding: 14px; margin-top: 16px; border-left: 4px solid #2b6e4e; background: rgba(43, 110, 78, 0.06); }
        .info-card p { font-size: 0.6rem; margin: 4px 0; line-height: 1.5; }
        
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); backdrop-filter: blur(24px); z-index: 1000; justify-content: center; align-items: center; }
        .modal-content { border-radius: 40px; max-width: 550px; width: 90%; max-height: 85vh; overflow-y: auto; border: 1px solid rgba(43, 110, 78, 0.4); animation: modalPop 0.3s ease; }
        @keyframes modalPop { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .modal-header { padding: 24px 28px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(43, 110, 78, 0.25); }
        .modal-header h3 { font-size: 1.2rem; font-weight: 700; color: #2b6e4e; }
        .close-modal { cursor: pointer; font-size: 1.5rem; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: 0.2s; }
        .close-modal:hover { background: rgba(43, 110, 78, 0.1); transform: rotate(90deg); }
        .modal-body { padding: 24px; }
        .detail-card { border-radius: 24px; padding: 18px; margin-bottom: 16px; background: rgba(0,0,0,0.04); line-height: 1.7; font-size: 0.85rem; }
        .btn-modal { padding: 14px; border-radius: 50px; width: 100%; cursor: pointer; font-weight: 700; border: none; margin-top: 10px; transition: 0.2s; }
        
        .toast { position: fixed; bottom: 28px; left: 28px; backdrop-filter: blur(20px); padding: 12px 24px; border-radius: 60px; z-index: 200; animation: slideInLeft 0.3s ease; border-left: 5px solid #2b6e4e; font-size: 0.8rem; font-weight: 600; }
        body.dark .toast { background: #1e2a24; color: #d1e6dc; }
        body.light .toast { background: #ffffff; color: #2b6e4e; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        @keyframes slideInLeft { from { transform: translateX(-100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        .rekom-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px; }
        .rekom-card { padding: 20px; border-radius: 24px; transition: 0.2s; cursor: pointer; border: 1px solid rgba(43, 110, 78, 0.15); }
        .rekom-card:hover { transform: translateY(-5px); border-color: #2b6e4e; }
        
        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 992px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 768px) { 
            .sidebar { width: 80px; padding: 24px 12px; } 
            .logo-text, .logo-small, .nav-link span, .theme-toggle span { display: none; } 
            .logo-icon { margin: 0 auto; transform: scale(0.9); } 
            .nav-link { justify-content: center; padding: 12px; } 
            .nav-link i { font-size: 1.3rem; } 
            .theme-toggle { justify-content: center; padding: 12px; } 
            .main-content { margin-left: 80px; padding: 16px 20px; } 
            .stats-row { grid-template-columns: 1fr; } 
            .top-bar { flex-direction: column; text-align: center; } 
            .weekly-prediction { flex-wrap: wrap; justify-content: center; }
            .pred-day-card { min-width: 85px; }
            .css-bar-chart { gap: 20px; padding: 8px 8px; height: 200px; }
            .css-bar-item { min-width: 60px; }
            .line-points { gap: 8px; }
            .line-point { min-width: 55px; }
            .province-right { width: 100px; }
            .risk-bar { width: 80px; }
        }
    </style>
</head>
<body class="dark">
<div class="bg-gradient"></div>

<div style="display: flex; min-height: 100vh;">
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon"><i class="fas fa-shield-haltered"></i></div>
            <div>
                <div class="logo-text">INA-PREDICT</div>
                <div class="logo-small">EARLY WARNING SYSTEM</div>
            </div>
        </div>
        <div class="nav-menu">
            <div class="nav-item"><a class="nav-link" href="index.html"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></div>
            <div class="nav-item"><a class="nav-link active" href="prediksi.html"><i class="fas fa-chart-line"></i><span>Prediksi Bencana</span></a></div>
            <div class="nav-item"><a class="nav-link" href="panduan.html"><i class="fas fa-hand-holding-heart"></i><span>Panduan Aksi</span></a></div>
            <div class="nav-item"><a class="nav-link" href="kontak.html"><i class="fas fa-phone-alt"></i><span>Kontak Darurat</span></a></div>
            <div class="nav-item"><a class="nav-link" href="donasi.html"><i class="fas fa-hand-holding-usd"></i><span>Donasi</span></a></div>
            <div class="nav-item"><a class="nav-link" href="hubungikami.html"><i class="fas fa-envelope"></i><span>Hubungi Kami</span></a></div>
        </div>
        <div class="theme-toggle" onclick="toggleTheme()">
            <i class="fas fa-sun"></i>
            <span>Dark / Light Mode</span>
            <i class="fas fa-moon"></i>
        </div>
        <div class="update-time"><i class="fas fa-clock"></i> Update: <span id="lastUpdate"></span><br>Data BNPB - BMKG - BPBD</div>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <h2><i class="fas fa-chart-line"></i> PREDIKSI & PERINGATAN DINI BENCANA</h2>
                <p>AI-Powered Prediction | Akurasi 94.7% | Update Real-time</p>
            </div>
            <div class="alert-status" onclick="showToast('🚨 AI PREDICTION ACTIVE | Sistem prediksi berbasis deep learning aktif')">
                <i class="fas fa-newspaper"></i> LIVE UPDATE
            </div>
        </div>

        <div class="prediction-hero">
            <h1><i class="fas fa-crystal-ball"></i> PREDIKSI BENCANA 7 HARI KE DEPAN</h1>
            <p>Sistem prediksi berbasis Artificial Intelligence & Machine Learning terintegrasi dengan BMKG, BNPB, dan citra satelit</p>
            <div class="ai-badge"><i class="fas fa-robot"></i> EARLY WARNING | Akurasi 94.7% | 10 Juni 2026</div>
        </div>

        <div class="stats-row" id="statsRow"></div>

        <div class="glass-card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-week"></i> 📅 PREDIKSI HARIAN (7 HARI KE DEPAN)</h3>
                <i class="fas fa-sync-alt" style="cursor:pointer; color:#2b6e4e;" onclick="refreshData()"></i>
            </div>
            <div class="weekly-prediction" id="weeklyPrediction"></div>
            <div class="info-card">
                <p><i class="fas fa-chart-line"></i> <strong>Analisis AI:</strong> Peningkatan risiko signifikan terjadi pada Kamis (12 Juni) dengan indeks bahaya mencapai 86% di zona Jawa-Bali. Faktor utama: curah hujan ekstrem 150mm/hari + aktivitas seismik.</p>
                <p><i class="fas fa-wind"></i> <strong>Peringatan Dini:</strong> Kecepatan angin di Selat Sunda diprediksi mencapai 45 km/jam. Nelayan dilarang melaut hingga 14 Juni 2026.</p>
                <p><i class="fas fa-waveform"></i> <strong>Aktivitas Seismik:</strong> 127 gempa tercatat dalam 24 jam terakhir, mayoritas magnitudo <3.0 SR.</p>
            </div>
        </div>

        <div class="two-columns">
            <div class="glass-card">
                <div class="card-header">
                    <h3><i class="fas fa-map-marked-alt"></i> 🏆 TOP 15 PROVINSI RISIKO TERTINGGI</h3>
                    <span style="font-size:0.55rem;">Klik untuk detail lengkap</span>
                </div>
                <div class="province-risk-list" id="provinceRiskList"></div>
                <div class="info-card" style="margin-top:12px;">
                    <p><i class="fas fa-chart-simple"></i> <strong>Rata-rata risiko nasional:</strong> 76.8% | <strong>Trend:</strong> <span style="color:#e07a5f;">Meningkat ↑6.2%</span> dibanding minggu lalu</p>
                    <p><i class="fas fa-bell"></i> <strong>Prioritas Penanganan:</strong> Jawa Barat, Banten, Jawa Timur</p>
                </div>
            </div>

            <div class="glass-card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-simple"></i> 📊 GRAFIK PREDIKSI BENCANA</h3>
                </div>
                <div class="charts-container">
                    <div class="chart-box" onclick="showDetail('📊 Prediksi 30 Hari ke Depan', '<strong>📈 DISTRIBUSI POTENSI BENCANA 30 HARI:</strong><br><br>🌊 Banjir: 45 kejadian (28.3%)<br>🌋 Gempa Bumi: 28 kejadian (17.6%)<br>⛰️ Tanah Longsor: 36 kejadian (22.6%)<br>🔥 Kebakaran Hutan: 18 kejadian (11.3%)<br>🌪️ Cuaca Ekstrem: 32 kejadian (20.1%)<br><br>📊 TOTAL: 159 kejadian bencana diprediksi<br><br>⚠️ INDIKASI: Angka ini adalah yang tertinggi sejak tahun 2024. Waspada ekstra!')">
                        <h4><i class="fas fa-water"></i> Prediksi 30 Hari ke Depan</h4>
                        <div class="css-bar-chart" id="barChart"></div>
                    </div>
                    <div class="chart-box" onclick="showDetail('📈 Tren Risiko Bulanan', '<strong>📊 TREN RISIKO BENCANA JUNI - DESEMBER 2026:</strong><br><br>📆 Juni 2026: 84% (PUNCAK RISIKO)<br>📆 Juli 2026: 78% (Masih Tinggi)<br>📆 Agustus 2026: 72% (Menurun)<br>📆 September 2026: 68% (Stabil)<br>📆 Oktober 2026: 70% (Meningkat)<br>📆 November 2026: 74% (Meningkat)<br>📆 Desember 2026: 79% (Akhir Tahun)<br><br>📈 KESIMPULAN:<br>Risiko tertinggi terjadi pada Juni 2026. Setelah September, risiko akan kembali meningkat memasuki musim hujan Desember.')">
                        <h4><i class="fas fa-chart-line"></i> Tren Risiko Bulanan (Juni - Desember 2026)</h4>
                        <div class="css-line-chart" id="lineChart"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="two-columns">
            <div class="glass-card">
                <div class="card-header">
                    <h3><i class="fas fa-cloud-sun-rain"></i> 🌧️ PERINGATAN DINI CUACA EKSTREM</h3>
                </div>
                <div id="weatherWarnings"></div>
                <div class="info-card">
                    <p><i class="fas fa-bell"></i> Peringatan dini berlaku untuk 2x24 jam ke depan. Segera cek pembaruan setiap 6 jam melalui aplikasi resmi BMKG.</p>
                    <p><i class="fas fa-phone-alt"></i> <strong>Hotline Darurat:</strong> BNPB 117 | BMKG 021-6546315 | BPBD 112</p>
                    <p><i class="fab fa-whatsapp"></i> <strong>Info Bencana:</strong> 0811-1234-5678 (24 jam)</p>
                </div>
            </div>

            <div class="glass-card">
                <div class="card-header">
                    <h3><i class="fas fa-building"></i> 🏙️ PREDIKSI RISIKO PER KOTA</h3>
                </div>
                <div class="search-box">
                    <input type="text" id="citySearch" class="city-search" placeholder="🔍 Cari kota atau provinsi..." onkeyup="filterCities()">
                    <select id="riskFilter" class="filter-select" onchange="filterCities()">
                        <option value="all">Semua Risiko (500+ Kota)</option>
                        <option value="high">Risiko Tinggi (≥75%)</option>
                        <option value="medium">Risiko Sedang (50-74%)</option>
                        <option value="low">Risiko Rendah (<50%)</option>
                    </select>
                </div>
                <div class="city-risk-grid" id="cityRiskGrid"></div>
                <div style="margin-top: 12px; text-align: center; font-size: 0.55rem;">
                    <i class="fas fa-database"></i> Menampilkan <span id="cityCount">0</span> dari 500+ kota | <i class="fas fa-mouse-pointer"></i> Klik untuk detail kontak darurat
                </div>
            </div>
        </div>

        <div class="glass-card">
            <div class="card-header">
                <h3><i class="fas fa-clipboard-list"></i> 🚨 REKOMENDASI TINDAKAN BERDASARKAN TINGKAT RISIKO</h3>
            </div>
            <div class="rekom-grid">
                <div class="rekom-card" style="background: rgba(200,80,60,0.1); border-left: 3px solid #e07a5f;" onclick="showDetail('⚠️ RISIKO TINGGI (≥75%)', '<strong>🔴 TINDAKAN DARURAT:</strong><br><br>✔️ SEGERA EVAKUASI ke tempat aman terdekat<br>✔️ Siapkan TAS DARURAT berisi dokumen, obat, makanan, air<br>✔️ Ikuti instruksi BPBD dan petugas di lapangan<br>✔️ Jauhi area rawan longsor, banjir, pantai<br>✔️ Hubungi HOTLINE 112 untuk bantuan darurat')">
                    <i class="fas fa-skull-crosswalk" style="color:#e07a5f; font-size:1.3rem;"></i>
                    <strong style="color:#e07a5f; display:block; margin-top:8px;">RISIKO TINGGI (≥75%)</strong>
                    <p style="font-size:0.6rem; margin-top:8px; line-height:1.5;">✔️ SEGERA EVAKUASI<br>✔️ Siapkan tas darurat<br>✔️ Ikuti instruksi petugas<br>✔️ Jauhi area rawan<br>✔️ Hubungi 112</p>
                </div>
                <div class="rekom-card" style="background: rgba(220,140,40,0.1); border-left: 3px solid #e0a343;" onclick="showDetail('⚠️ RISIKO SEDANG (50-74%)', '<strong>🟠 TINDAKAN SIAGA:</strong><br><br>✔️ Tingkatkan KEWASPADAAN dan pantau info setiap 2 jam<br>✔️ Hindari area rawan longsor/banjir saat hujan deras<br>✔️ Cek JALUR EVAKUASI terdekat dari rumah Anda<br>✔️ Siapkan PERLENGKAPAN DARURAT di tempat mudah dijangkau<br>✔️ Simpan NOMOR DARURAT di ponsel')">
                    <i class="fas fa-exclamation-triangle" style="color:#e0a343; font-size:1.3rem;"></i>
                    <strong style="color:#e0a343; display:block; margin-top:8px;">RISIKO SEDANG (50-74%)</strong>
                    <p style="font-size:0.6rem; margin-top:8px; line-height:1.5;">✔️ Tingkatkan kewaspadaan<br>✔️ Hindari area rawan<br>✔️ Cek jalur evakuasi<br>✔️ Siapkan perlengkapan<br>✔️ Simpan nomor darurat</p>
                </div>
                <div class="rekom-card" style="background: rgba(61,155,109,0.1); border-left: 3px solid #3d9b6d;" onclick="showDetail('✅ RISIKO RENDAH (<50%)', '<strong>🟢 TINDAKAN SIAGA RENDAH:</strong><br><br>✔️ Tetap SIAGA dan jangan lengah meski risiko rendah<br>✔️ Persiapkan PERLENGKAPAN DARURAT di rumah<br>✔️ Update informasi rutin melalui BMKG dan BNPB<br>✔️ Ikuti SOSIALISASI KEBENCANAAN di lingkungan Anda<br>✔️ Download APLIKASI EARLY WARNING di ponsel')">
                    <i class="fas fa-check-circle" style="color:#3d9b6d; font-size:1.3rem;"></i>
                    <strong style="color:#3d9b6d; display:block; margin-top:8px;">RISIKO RENDAH (<50%)</strong>
                    <p style="font-size:0.6rem; margin-top:8px; line-height:1.5;">✔️ Tetap siaga<br>✔️ Persiapkan perlengkapan<br>✔️ Update info rutin<br>✔️ Ikuti sosialisasi<br>✔️ Download aplikasi EWS</p>
                </div>
            </div>
        </div>

        <div style="text-align:center; font-size:0.45rem; opacity:0.5; margin-top:16px; padding:12px;">
            <i class="fas fa-shield-alt"></i> Sumber: AI Prediction Engine | Data BMKG - BNPB - LAPAN - BPBD | Update real-time setiap 5 menit
        </div>
    </main>
</div>

<div id="detailModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Detail Prediksi</h3>
            <div class="close-modal" onclick="closeModal()"><i class="fas fa-times"></i></div>
        </div>
        <div class="modal-body" id="modalBody"></div>
    </div>
</div>

<script>
function toggleTheme() {
    if(document.body.classList.contains('dark')) {
        document.body.classList.remove('dark');
        document.body.classList.add('light');
        localStorage.setItem('theme', 'light');
        showToast('🌞 Light mode aktif | Tampilan terang');
    } else {
        document.body.classList.remove('light');
        document.body.classList.add('dark');
        localStorage.setItem('theme', 'dark');
        showToast('🌙 Dark mode aktif | Tampilan gelap');
    }
}

if(localStorage.getItem('theme') === 'light') {
    document.body.classList.remove('dark');
    document.body.classList.add('light');
}

// DATA
const weeklyData = [
    { day: "Selasa", date: "10 Juni", risk: 72, level: "medium", status: "WASPADA", desc: "Potensi hujan lebat di Jabar, Jateng, Jatim dengan intensitas 50-100mm/hari. Waspada banjir bandang di daerah aliran sungai." },
    { day: "Rabu", date: "11 Juni", risk: 78, level: "medium", status: "SIAGA", desc: "Intensitas hujan meningkat signifikan mencapai 120mm/hari. Potensi longsor di daerah perbukitan." },
    { day: "Kamis", date: "12 Juni", risk: 86, level: "high", status: "DARURAT", desc: "Puncak musim hujan! Curah hujan ekstrem 160mm/hari. Risiko sangat tinggi untuk banjir, longsor, dan angin puting beliung." },
    { day: "Jumat", date: "13 Juni", risk: 83, level: "high", status: "SIAGA", desc: "Hujan masih tinggi 130mm/hari. Waspada banjir rob di pesisir utara Jawa." },
    { day: "Sabtu", date: "14 Juni", risk: 76, level: "medium", status: "WASPADA", desc: "Intensitas mulai menurun menjadi 80mm/hari. Tetap waspada terhadap dampak lanjutan." },
    { day: "Minggu", date: "15 Juni", risk: 68, level: "medium", status: "WASPADA", desc: "Cuaca mulai stabil, hujan 50mm/hari. Risiko menuju normal." },
    { day: "Senin", date: "16 Juni", risk: 55, level: "low", status: "NORMAL", desc: "Kondisi mulai normal dengan hujan ringan 20mm/hari." }
];

const provinceRisks = [
    { name: "Jawa Barat", risk: 92, level: "high", mainThreat: "Banjir Bandang, Longsor", population: "49.9 Juta", districts: 27 },
    { name: "Banten", risk: 89, level: "high", mainThreat: "Banjir, Tsunami", population: "12.4 Juta", districts: 8 },
    { name: "Jawa Timur", risk: 87, level: "high", mainThreat: "Banjir, Gunung Semeru", population: "40.9 Juta", districts: 38 },
    { name: "Jawa Tengah", risk: 84, level: "high", mainThreat: "Longsor, Banjir", population: "36.7 Juta", districts: 35 },
    { name: "Sulawesi Tengah", risk: 82, level: "high", mainThreat: "Gempa, Likuefaksi", population: "3.0 Juta", districts: 13 },
    { name: "Sumatera Barat", risk: 80, level: "high", mainThreat: "Gempa, Tsunami", population: "5.5 Juta", districts: 19 },
    { name: "Kalimantan Selatan", risk: 79, level: "high", mainThreat: "Banjir Bandang", population: "4.1 Juta", districts: 13 },
    { name: "Papua", risk: 77, level: "high", mainThreat: "Gempa, Longsor", population: "4.3 Juta", districts: 28 },
    { name: "Aceh", risk: 74, level: "medium", mainThreat: "Cuaca Ekstrem", population: "5.4 Juta", districts: 23 },
    { name: "Riau", risk: 72, level: "medium", mainThreat: "Karhutla", population: "6.4 Juta", districts: 12 },
    { name: "Sumatera Utara", risk: 70, level: "medium", mainThreat: "Banjir, Cuaca", population: "14.8 Juta", districts: 33 },
    { name: "Lampung", risk: 68, level: "medium", mainThreat: "Banjir, Gempa", population: "9.1 Juta", districts: 15 },
    { name: "DKI Jakarta", risk: 67, level: "medium", mainThreat: "Banjir, Rob", population: "10.6 Juta", districts: 6 },
    { name: "Sulawesi Selatan", risk: 65, level: "medium", mainThreat: "Banjir, Longsor", population: "9.1 Juta", districts: 24 },
    { name: "Bali", risk: 58, level: "low", mainThreat: "Cuaca Ekstrem", population: "4.3 Juta", districts: 9 }
];

const cityRisks = [];
const citiesData = {
    "Jawa Barat": ["Bandung","Bekasi","Bogor","Depok","Sukabumi","Cianjur","Garut","Tasikmalaya","Cirebon","Karawang"],
    "Jawa Timur": ["Surabaya","Malang","Kediri","Blitar","Lumajang","Sidoarjo","Jember","Probolinggo"],
    "Jawa Tengah": ["Semarang","Surakarta","Magelang","Purwokerto","Pekalongan","Tegal","Salatiga"],
    "Banten": ["Serang","Cilegon","Tangerang","Pandeglang","Lebak","Tangerang Selatan"],
    "DKI Jakarta": ["Jakarta Pusat","Jakarta Barat","Jakarta Selatan","Jakarta Timur","Jakarta Utara"],
    "Sumatera Barat": ["Padang","Bukittinggi","Payakumbuh","Pariaman"],
    "Sumatera Utara": ["Medan","Binjai","Sibolga","Tebing Tinggi"],
    "Riau": ["Pekanbaru","Dumai","Bengkalis"],
    "Lampung": ["Bandar Lampung","Metro","Kotabumi"],
    "Kalimantan Selatan": ["Banjarmasin","Banjarbaru","Martapura"],
    "Sulawesi Tengah": ["Palu","Poso","Luwuk"],
    "Papua": ["Jayapura","Merauke","Timika"],
    "Aceh": ["Banda Aceh","Lhokseumawe","Langsa"],
    "Bali": ["Denpasar","Badung","Gianyar","Singaraja"]
};

for (const [province, cities] of Object.entries(citiesData)) {
    const provRisk = provinceRisks.find(p => p.name === province) || { risk: 60, level: "medium" };
    cities.forEach(city => {
        let variation = (Math.random() - 0.5) * 15;
        let risk = Math.min(98, Math.max(25, provRisk.risk + variation));
        let level = risk >= 75 ? "high" : (risk >= 50 ? "medium" : "low");
        cityRisks.push({ city, province, risk: Math.round(risk), level });
    });
}
cityRisks.sort((a,b) => b.risk - a.risk);

const weatherWarnings = [
    { type: "🌊 BANJIR BANDANG", locations: "Garut, Sukabumi, Cianjur, Bandung", time: "10-12 Juni", severity: "high", desc: "Potensi banjir bandang dengan ketinggian mencapai 2-3 meter di daerah aliran sungai Citarum." },
    { type: "⛰️ TANAH LONGSOR", locations: "Puncak, Banjarnegara, Sumedang", time: "11-14 Juni", severity: "high", desc: "Lereng curam rawan longsor. Hindari perjalanan malam hari di jalur Puncak." },
    { type: "🌋 GUNUNG SEMERU", locations: "Lumajang, Malang", time: "Aktif - AWAS", severity: "high", desc: "Status AWAS (Level IV). Radius 8 km dari puncak dilarang beraktivitas." },
    { type: "🔥 KARHUTLA", locations: "Riau, Kalimantan Selatan, Sumsel", time: "12-16 Juni", severity: "medium", desc: "Titik api meningkat 45% dibanding kemarin. Kualitas udara tidak sehat." },
    { type: "🌪️ ANGIN PUTING BELIUNG", locations: "Indramayu, Cirebon, Brebes", time: "11 Juni", severity: "medium", desc: "Potensi angin kencang >60 km/jam." },
    { type: "🌊 GELOMBANG TINGGI", locations: "Selat Sunda, Samudra Hindia", time: "10-13 Juni", severity: "high", desc: "Tinggi gelombang 4-6 meter. Nelayan dilarang melaut." }
];

function renderStatsRow() {
    document.getElementById('statsRow').innerHTML = `
        <div class="pred-stat-card" onclick="showDetail('Risiko Nasional', '📊 NILAI: 76.8% (RISIKO SEDANG-MENINGKAT)\\n\\n📋 DESKRIPSI:\\nRisiko bencana secara nasional dalam 7 hari ke depan. Berdasarkan analisis AI dari 15 parameter meliputi curah hujan (345 mm/minggu), aktivitas seismik (127 gempa/hari), kecepatan angin (35 km/jam), kelembaban (85%).')">
            <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-value">76.8%</div>
            <div class="stat-label">Risiko Nasional</div>
        </div>
        <div class="pred-stat-card" onclick="showDetail('Provinsi Darurat', '📊 STATUS: 8 PROVINSI DARURAT\\n\\n📋 Jawa Barat (92%), Banten (89%), Jawa Timur (87%), Jawa Tengah (84%), Sulawesi Tengah (82%), Sumatera Barat (80%), Kalimantan Selatan (79%), Papua (77%)')">
            <div class="stat-icon"><i class="fas fa-map-location-dot"></i></div>
            <div class="stat-value">8</div>
            <div class="stat-label">Provinsi Darurat</div>
        </div>
        <div class="pred-stat-card" onclick="showDetail('Kota Berisiko', '📊 74 KOTA/KABUPATEN RISIKO TINGGI (>75%)\\n\\n🏆 TOP 3: Bandung (94%), Bogor (93%), Bekasi (91%)')">
            <div class="stat-icon"><i class="fas fa-city"></i></div>
            <div class="stat-value">74</div>
            <div class="stat-label">Kota Berisiko</div>
        </div>
        <div class="pred-stat-card" onclick="showDetail('Perkiraan Pengungsi', '📊 ESTIMASI PENGUNGSI BARU: 38.000 JIWA\\n\\nJawa Barat: 12.000, Banten: 7.000, Jawa Timur: 6.000, Jawa Tengah: 5.000, Lainnya: 8.000')">
            <div class="stat-icon"><i class="fas fa-users"></i></div>
            <div class="stat-value">+38K</div>
            <div class="stat-label">Perkiraan Pengungsi</div>
        </div>
        <div class="pred-stat-card" onclick="showDetail('Akurasi Prediksi', '📊 AKURASI AI: 94.7%\\n\\nBanjir: 96.2%, Gempa: 91.5%, Longsor: 93.8%, Cuaca Ekstrem: 94.1%')">
            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            <div class="stat-value">94.7%</div>
            <div class="stat-label">Akurasi Prediksi</div>
        </div>
    `;
}

function renderWeekly() {
    document.getElementById('weeklyPrediction').innerHTML = weeklyData.map(d => `
        <div class="pred-day-card" onclick="showDetail('${d.day} ${d.date}', '📅 ${d.day}, ${d.date}\\n\\n🎯 RISIKO: ${d.risk}%\\n⚠️ STATUS: ${d.status}\\n\\n📝 DESKRIPSI:\\n${d.desc}\\n\\n🔔 REKOMENDASI:\\n${d.risk >= 80 ? '🚨 SEGERA EVAKUASI! Hubungi BPBD 112. Siapkan tas darurat.' : (d.risk >= 60 ? '⚠️ TINGKATKAN KEWASPADAAN! Pantau info setiap 2 jam.' : '✅ TETAP TENANG! Tetap waspada.')}')">
            <div class="pred-day-name">${d.day}</div>
            <div class="pred-date">${d.date}</div>
            <div class="pred-risk ${d.level}">${d.risk}%</div>
            <span class="pred-status status-${d.level === 'high' ? 'high' : (d.level === 'medium' ? 'medium' : 'low')}">${d.status}</span>
        </div>
    `).join('');
}

function renderProvinceRisks() {
    document.getElementById('provinceRiskList').innerHTML = provinceRisks.map(p => `
        <div class="province-risk-item" onclick="showDetail('Provinsi ${p.name}', '<strong>📍 ${p.name}</strong><br><br>📊 RISIKO: ${p.risk}%<br>🌋 ANCAMAN UTAMA: ${p.mainThreat}<br>👥 POPULASI: ${p.population}<br>🏙️ KABUPATEN/KOTA: ${p.districts} daerah<br><br>${p.risk >= 80 ? '🔴 STATUS DARURAT: Segera evakuasi!' : (p.risk >= 70 ? '🟠 STATUS SIAGA TINGGI: Tingkatkan kewaspadaan!' : '🟡 STATUS SIAGA: Tetap waspada!')}')">
            <div class="province-left">
                <strong>${p.name}</strong>
                <span>${p.mainThreat}</span>
            </div>
            <div class="province-right">
                <div class="province-percent" style="color:${p.level === 'high' ? '#e07a5f' : (p.level === 'medium' ? '#e0a343' : '#3d9b6d')};">${p.risk}%</div>
                <div class="risk-bar"><div class="risk-fill ${p.level}" style="width: ${p.risk}%;"></div></div>
            </div>
        </div>
    `).join('');
}

function renderBarChart() {
    const data = [
        { label: "Banjir", value: 45, color: "#2b6e4e" },
        { label: "Gempa", value: 28, color: "#e07a5f" },
        { label: "Longsor", value: 36, color: "#e0a343" },
        { label: "Karhutla", value: 18, color: "#c25d45" },
        { label: "Cuaca", value: 32, color: "#3d9b6d" }
    ];
    const maxValue = Math.max(...data.map(d => d.value));
    document.getElementById('barChart').innerHTML = `
        <div class="css-bar-chart">
            ${data.map(d => `<div class="css-bar-item"><div class="css-bar" style="height: ${(d.value / maxValue) * 150}px; background: linear-gradient(180deg, ${d.color}, ${d.color}aa);"></div><div class="css-bar-label">${d.label}</div><div class="css-bar-value">${d.value}</div></div>`).join('')}
        </div>
    `;
}

function renderLineChart() {
    const months = ['Juni', 'Juli', 'Agustus', 'Sep', 'Okt', 'Nov', 'Des'];
    const risks = [84, 78, 72, 68, 70, 74, 79];
    document.getElementById('lineChart').innerHTML = `
        <div class="line-points">
            ${months.map((m, i) => `<div class="line-point"><div class="line-point-value">${risks[i]}%</div><div class="line-point-label">${m}</div></div>`).join('')}
        </div>
    `;
}

function renderCityRisks(filter="all", search="") {
    let filtered = cityRisks.filter(c => filter === "all" || c.level === filter);
    if (search) filtered = filtered.filter(c => c.city.toLowerCase().includes(search.toLowerCase()) || c.province.toLowerCase().includes(search.toLowerCase()));
    document.getElementById('cityRiskGrid').innerHTML = filtered.slice(0, 60).map(c => `
        <div class="city-risk-card" onclick="showDetail('${c.city}, ${c.province}', '<strong>🏙️ ${c.city}, ${c.province}</strong><br><br>📊 RISIKO: ${c.risk}%<br>⚠️ KATEGORI: ${c.level === 'high' ? 'TINGGI' : (c.level === 'medium' ? 'SEDANG' : 'RENDAH')}<br><br>📞 KONTAK PENTING:<br>• BPBD: 112<br>• Ambulans: 118<br>• Damkar: 113<br><br>${c.level === 'high' ? '🔴 SEGERA EVAKUASI! Siapkan tas darurat.' : (c.level === 'medium' ? '🟠 Tingkatkan kewaspadaan!' : '🟢 Tetap siaga!')}')">
            <div class="city-name-large"><span><i class="fas fa-map-pin"></i> ${c.city}</span><span style="color:${c.level === 'high' ? '#e07a5f' : (c.level === 'medium' ? '#e0a343' : '#3d9b6d')};">${c.risk}%</span></div>
            <div class="city-risk-value">${c.province}</div>
            <div class="city-risk-bar"><div class="risk-fill ${c.level}" style="width: ${c.risk}%;"></div></div>
        </div>
    `).join('');
    document.getElementById('cityCount').innerHTML = filtered.length;
}

function renderWeatherWarnings() {
    document.getElementById('weatherWarnings').innerHTML = weatherWarnings.map(w => `
        <div class="warning-card" onclick="showDetail('${w.type}', '<strong>⚠️ ${w.type}</strong><br><br>📍 LOKASI: ${w.locations}<br>⏰ WAKTU: ${w.time}<br>🔴 TINGKAT: ${w.severity === 'high' ? 'DARURAT' : 'WASPADA'}<br><br>📝 ${w.desc}<br><br>${w.severity === 'high' ? '🔴 SEGERA EVAKUASI ke tempat aman!' : '🟠 Tingkatkan kewaspadaan!'}')">
            <div style="display:flex; justify-content:space-between;"><span style="font-weight:700; font-size:0.7rem;">${w.type}</span><span style="font-size:0.45rem; padding:2px 8px; border-radius:20px; background:${w.severity === 'high' ? 'rgba(200,80,60,0.2)' : 'rgba(220,140,40,0.2)'};">${w.time}</span></div>
            <div style="font-size:0.55rem; margin-top:5px;">📍 ${w.locations}</div>
        </div>
    `).join('');
}

function filterCities() {
    renderCityRisks(document.getElementById('riskFilter').value, document.getElementById('citySearch').value);
}

function refreshData() {
    renderBarChart();
    renderLineChart();
    renderWeekly();
    renderProvinceRisks();
    renderCityRisks();
    renderWeatherWarnings();
    document.getElementById('lastUpdate').innerHTML = new Date().toLocaleString('id-ID');
    showToast('📊 Data prediksi berhasil diperbarui! ' + new Date().toLocaleTimeString('id-ID'));
}

function showDetail(title, content) {
    document.getElementById('modalTitle').innerHTML = title;
    document.getElementById('modalBody').innerHTML = `<div class="detail-card">${content.replace(/\n/g,'<br>')}</div><button class="btn-modal" onclick="closeModal()" style="background: linear-gradient(135deg, #2b6e4e, #3d9b6d); color:white;">Tutup</button>`;
    document.getElementById('detailModal').style.display = 'flex';
}

function closeModal() { 
    document.getElementById('detailModal').style.display = 'none'; 
}

function showToast(msg) { 
    const t = document.createElement('div'); 
    t.className = 'toast'; 
    t.innerHTML = `<i class="fas fa-bell"></i> ${msg}`; 
    document.body.appendChild(t); 
    setTimeout(() => t.remove(), 2800); 
}

document.getElementById('lastUpdate').innerHTML = new Date().toLocaleString('id-ID');
renderStatsRow();
renderWeekly();
renderProvinceRisks();
renderBarChart();
renderLineChart();
renderCityRisks();
renderWeatherWarnings();

setInterval(() => refreshData(), 300000);
</script>
</body>
</html>"""
components.html(html_content, height=1200, scrolling=True)
