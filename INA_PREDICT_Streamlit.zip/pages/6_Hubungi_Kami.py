
import streamlit as st
import streamlit.components.v1 as components

html_content = r"""<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, viewport-fit=cover">
    <title>INA-PREDICT | Hubungi Kami - WhatsApp Otomatis</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Space Grotesk', 'Inter', sans-serif; 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
            min-height: 100vh;
            font-size: 15px;
            line-height: 1.45;
        }
        
        body.dark { background: #0a0f0d; color: #e2e8e4; }
        body.dark .bg-premium { background: radial-gradient(circle at 30% 20%, #0a1a12, #020504); }
        body.dark .sidebar { background: rgba(6, 12, 10, 0.97); border-right-color: rgba(43, 110, 78, 0.4); backdrop-filter: blur(20px); }
        body.dark .form-card, body.dark .info-card, body.dark .top-bar,
        body.dark .hero-card, body.dark .modal-content, body.dark .government-card,
        body.dark .admin-card { 
            background: rgba(18, 28, 23, 0.9); 
            border-color: rgba(43, 110, 78, 0.3); 
        }
        body.dark .nav-link { color: #b8d5c8; }
        body.dark .nav-link:hover, body.dark .nav-link.active { background: rgba(43, 110, 78, 0.12); color: #2b6e4e !important; border-left-color: #2b6e4e; }
        body.dark .form-input, body.dark .form-select, body.dark .form-textarea { background: #1a1f1c; border-color: #2a3a32; color: #e2e8e4; }
        body.dark .toast { background: #1e2a24; color: #d1e6dc; }
        body.dark .card-header h3 { color: #3d9b6d; }
        body.dark .gov-name { color: #3d9b6d; }
        body.dark .gov-number { color: #3d9b6d; }
        
        body.light { background: #f0f4f1; color: #1a2c24; }
        body.light .bg-premium { background: radial-gradient(circle at 30% 20%, #e2ece6, #d3e0d8); }
        body.light .sidebar { background: rgba(255, 255, 255, 0.97); border-right-color: rgba(43, 110, 78, 0.2); }
        body.light .form-card, body.light .info-card, body.light .top-bar,
        body.light .hero-card, body.light .modal-content, body.light .government-card,
        body.light .admin-card { 
            background: rgba(255, 255, 255, 0.94); 
            border-color: rgba(43, 110, 78, 0.15); 
            box-shadow: 0 8px 32px rgba(0,0,0,0.03);
        }
        body.light .nav-link { color: #4a6a5a; }
        body.light .nav-link:hover, body.light .nav-link.active { background: rgba(43, 110, 78, 0.12); color: #2b6e4e !important; border-left-color: #2b6e4e; }
        body.light .form-input, body.light .form-select, body.light .form-textarea { background: #ffffff; border-color: #d0ddd5; color: #1a2c24; }
        body.light .toast { background: #ffffff; color: #2b6e4e; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        body.light .card-header h3 { color: #2b6e4e; }
        body.light .gov-name { color: #2b6e4e; }
        body.light .gov-number { color: #2b6e4e; }
        
        .bg-premium { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: -2; transition: all 0.3s; }
        
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: rgba(43, 110, 78, 0.1); border-radius: 10px; }
        ::-webkit-scrollbar-thumb { background: linear-gradient(135deg, #2b6e4e, #3d9b6d); border-radius: 10px; }
        
        .sidebar { width: 280px; padding: 32px 24px; position: fixed; height: 100vh; overflow-y: auto; z-index: 20; border-right: 1px solid; transition: all 0.3s ease; }
        .logo-area { display: flex; align-items: center; gap: 14px; margin-bottom: 48px; }
        .logo-icon { width: 52px; height: 52px; background: linear-gradient(135deg, #2b6e4e, #3d9b6d); border-radius: 20px; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; color: white; box-shadow: 0 8px 20px rgba(43,110,78,0.3); animation: float 3s ease-in-out infinite; }
        @keyframes float { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        .logo-text { font-size: 1.4rem; font-weight: 800; letter-spacing: -0.5px; background: linear-gradient(135deg, #2b6e4e, #3d9b6d); -webkit-background-clip: text; background-clip: text; color: transparent; }
        body.dark .logo-text { background: linear-gradient(135deg, #3d9b6d, #5cb885); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .logo-small { font-size: 0.6rem; opacity: 0.65; letter-spacing: 1.5px; margin-top: 4px; color: inherit; }
        .nav-menu { list-style: none; margin-top: 20px; }
        .nav-item { margin: 10px 0; }
        .nav-link { display: flex; align-items: center; gap: 14px; padding: 12px 18px; border-radius: 14px; font-weight: 600; font-size: 0.9rem; text-decoration: none; transition: all 0.2s; border-left: 3px solid transparent; cursor: pointer; }
        .nav-link:hover, .nav-link.active { background: rgba(43, 110, 78, 0.12); transform: translateX(4px); border-left-color: #2b6e4e; }
        
        .theme-toggle { display: flex; align-items: center; justify-content: space-between; margin-top: 40px; padding: 12px 18px; background: rgba(43, 110, 78, 0.12); border-radius: 50px; cursor: pointer; font-weight: 500; font-size: 0.85rem; transition: 0.2s; }
        .theme-toggle:hover { background: rgba(43, 110, 78, 0.25); }
        .update-time { margin-top: 24px; padding-top: 20px; border-top: 1px solid rgba(43, 110, 78, 0.2); font-size: 0.6rem; text-align: center; opacity: 0.7; }
        
        .main-content { margin-left: 280px; padding: 24px 32px; transition: all 0.3s; }
        .top-bar { backdrop-filter: blur(16px); border-radius: 28px; padding: 18px 28px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 16px; border: 1px solid; }
        .top-bar h2 { font-size: 1.2rem; font-weight: 800; background: linear-gradient(135deg, #2b6e4e, #3d9b6d); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .top-bar p { font-size: 0.7rem; opacity: 0.7; margin-top: 4px; }
        .alert-status { background: linear-gradient(135deg, #2b6e4e, #3d9b6d); color: white; padding: 10px 28px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; cursor: pointer; animation: pulse 2s infinite; border: none; transition: 0.2s; }
        .alert-status:hover { transform: scale(1.02); }
        @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(43, 110, 78, 0.5); } 50% { box-shadow: 0 0 0 8px rgba(43, 110, 78, 0); } }
        
        .hero-card { border-radius: 32px; padding: 40px 30px; margin-bottom: 28px; text-align: center; border: 1px solid; backdrop-filter: blur(12px); }
        .hero-card h1 { font-size: 1.8rem; margin-bottom: 12px; background: linear-gradient(135deg, #2b6e4e, #3d9b6d); -webkit-background-clip: text; background-clip: text; color: transparent; }
        
        .admins-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 28px;
            margin: 32px 0;
        }
        .admin-card {
            border-radius: 32px;
            padding: 28px 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid;
            backdrop-filter: blur(12px);
            position: relative;
            overflow: hidden;
        }
        .admin-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(43,110,78,0.08), transparent);
            transition: 0.6s;
        }
        .admin-card:hover::before { left: 100%; }
        .admin-card:hover {
            transform: translateY(-8px);
            border-color: #2b6e4e !important;
            box-shadow: 0 20px 35px rgba(43,110,78,0.2);
        }
        .admin-avatar {
            width: 90px;
            height: 90px;
            background: linear-gradient(135deg, #2b6e4e20, #3d9b6d20);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 2.5rem;
            color: #2b6e4e;
        }
        body.dark .admin-avatar { color: #3d9b6d; }
        .admin-name {
            font-size: 1.2rem;
            font-weight: 800;
            margin-bottom: 6px;
            background: linear-gradient(135deg, #2b6e4e, #3d9b6d);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        .admin-role {
            font-size: 0.65rem;
            opacity: 0.7;
            margin-bottom: 12px;
        }
        .admin-platform {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(37, 211, 102, 0.15);
            padding: 8px 18px;
            border-radius: 40px;
            font-size: 0.7rem;
            font-weight: 600;
            margin: 12px 0;
            color: #25D366;
        }
        .admin-number {
            font-size: 0.9rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            margin-top: 8px;
        }
        .badge-online {
            display: inline-block;
            width: 10px;
            height: 10px;
            background: #22c55e;
            border-radius: 50%;
            margin-left: 8px;
            box-shadow: 0 0 5px #22c55e;
            animation: pulse-online 1.5s infinite;
        }
        @keyframes pulse-online {
            0%,100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(1.2); }
        }
        
        .form-card, .government-card {
            border-radius: 32px;
            padding: 28px;
            border: 1px solid;
            backdrop-filter: blur(12px);
            margin-bottom: 28px;
        }
        
        .card-header { display: flex; align-items: center; gap: 12px; margin-bottom: 24px; border-bottom: 2px solid rgba(43, 110, 78, 0.2); padding-bottom: 14px; }
        .card-header i { font-size: 1.4rem; color: #2b6e4e; }
        .card-header h3 { font-size: 1rem; font-weight: 800; }
        
        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 0.7rem; font-weight: 600; margin-bottom: 8px; }
        .form-input, .form-select, .form-textarea { width: 100%; padding: 14px 18px; border-radius: 20px; border: 1px solid; font-size: 0.8rem; outline: none; transition: 0.2s; font-family: inherit; background: transparent; }
        .form-input:focus, .form-select:focus, .form-textarea:focus { border-color: #2b6e4e; box-shadow: 0 0 0 3px rgba(43,110,78,0.1); }
        .btn-submit { background: linear-gradient(135deg, #2b6e4e, #3d9b6d); color: white; border: none; padding: 14px 28px; border-radius: 50px; font-weight: 700; font-size: 0.85rem; cursor: pointer; transition: 0.2s; width: 100%; }
        .btn-submit:hover { transform: translateY(-2px); filter: brightness(1.05); }
        .btn-submit:disabled { opacity: 0.6; cursor: not-allowed; }
        
        .info-badge {
            background: rgba(43, 110, 78, 0.08);
            padding: 12px;
            border-radius: 20px;
            margin-bottom: 20px;
            border-left: 3px solid #25D366;
        }
        .info-badge p { font-size: 0.6rem; margin: 0; }
        
        .government-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); 
            gap: 16px; 
            margin-top: 16px; 
            max-height: 400px; 
            overflow-y: auto; 
            padding-right: 8px; 
        }
        .government-card-item { 
            border-radius: 24px; 
            padding: 16px; 
            cursor: pointer; 
            transition: 0.2s; 
            border: 1px solid rgba(43, 110, 78, 0.15); 
        }
        .government-card-item:hover { 
            transform: translateY(-4px); 
            border-color: #2b6e4e; 
            background: rgba(43, 110, 78, 0.08); 
        }
        .gov-name { font-weight: 800; font-size: 0.8rem; display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
        .gov-number { font-size: 0.7rem; font-weight: 700; margin-top: 8px; }
        
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); backdrop-filter: blur(24px); z-index: 1000; justify-content: center; align-items: center; }
        .modal-content { border-radius: 40px; max-width: 550px; width: 90%; max-height: 85vh; overflow-y: auto; border: 1px solid rgba(43, 110, 78, 0.4); animation: modalPop 0.3s ease; }
        @keyframes modalPop { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        .modal-header { padding: 24px 28px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(43, 110, 78, 0.25); }
        .modal-header h3 { font-size: 1.2rem; font-weight: 800; color: #2b6e4e; }
        body.dark .modal-header h3 { color: #3d9b6d; }
        .close-modal { cursor: pointer; font-size: 1.5rem; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: 0.2s; }
        .close-modal:hover { background: rgba(43, 110, 78, 0.15); transform: rotate(90deg); }
        .modal-body { padding: 24px; }
        .detail-card { border-radius: 24px; padding: 20px; margin-bottom: 16px; background: rgba(0,0,0,0.04); line-height: 1.7; font-size: 0.85rem; }
        
        .toast { position: fixed; bottom: 28px; left: 28px; backdrop-filter: blur(20px); padding: 12px 24px; border-radius: 60px; z-index: 200; animation: slideInLeft 0.3s ease; border-left: 5px solid #25D366; font-size: 0.8rem; font-weight: 600; }
        @keyframes slideInLeft { 
            from { transform: translateX(-100px); opacity: 0; } 
            to { transform: translateX(0); opacity: 1; } 
        }
        
        @media (max-width: 768px) { 
            .sidebar { width: 80px; padding: 24px 12px; } 
            .logo-text, .logo-small, .nav-link span, .theme-toggle span { display: none; } 
            .logo-icon { margin: 0 auto; transform: scale(0.9); } 
            .nav-link { justify-content: center; padding: 12px; } 
            .nav-link i { font-size: 1.3rem; } 
            .theme-toggle { justify-content: center; padding: 12px; } 
            .main-content { margin-left: 80px; padding: 16px 20px; } 
            .top-bar { flex-direction: column; text-align: center; }
            .hero-card h1 { font-size: 1.3rem; }
            .admin-avatar { width: 70px; height: 70px; font-size: 2rem; }
            .admin-name { font-size: 1rem; }
            .admins-container { grid-template-columns: 1fr; gap: 20px; }
        }
    </style>
</head>
<body class="dark">
<div class="bg-premium"></div>

<div style="display: flex; min-height: 100vh;">
    <aside class="sidebar">
        <div class="logo-area"><div class="logo-icon"><i class="fas fa-shield-haltered"></i></div><div><div class="logo-text">INA-PREDICT</div><div class="logo-small">EARLY WARNING SYSTEM</div></div></div>
        <ul class="nav-menu">
            <li class="nav-item"><a class="nav-link" href="index.html"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="prediksi.html"><i class="fas fa-chart-line"></i><span>Prediksi Bencana</span></a></li>
            <li class="nav-item"><a class="nav-link" href="panduan.html"><i class="fas fa-hand-holding-heart"></i><span>Panduan Aksi</span></a></li>
            <li class="nav-item"><a class="nav-link" href="kontak.html"><i class="fas fa-phone-alt"></i><span>Kontak Darurat</span></a></li>
            <li class="nav-item"><a class="nav-link" href="donasi.html"><i class="fas fa-hand-holding-usd"></i><span>Donasi</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="hubungi.html"><i class="fas fa-envelope"></i><span>Hubungi Kami</span></a></li>
        </ul>
        <div class="theme-toggle" onclick="toggleTheme()">
            <i class="fas fa-sun"></i>
            <span>Dark / Light Mode</span>
            <i class="fas fa-moon"></i>
        </div>
        <div class="update-time"><i class="fas fa-clock"></i> Update: <span id="lastUpdate"></span><br>Data BNPB - BMKG - BPBD</div>
    </aside>

    <main class="main-content">
        <div class="top-bar">
            <div>
                <h2><i class="fab fa-whatsapp"></i> HUBUNGI KAMI VIA WHATSAPP</h2>
                <p>Keluhan, laporan bencana, dan aspirasi akan LANGSUNG terkirim ke 3 Admin via Fonnte</p>
            </div>
            <div class="alert-status" onclick="showToast('💬 Laporan akan otomatis terkirim ke WhatsApp 3 Admin!')"><i class="fab fa-whatsapp"></i> NOTIF OTOMATIS</div>
        </div>

        <div class="hero-card">
            <h1><i class="fab fa-whatsapp"></i> SALURAN ASPIRASI WHATSAPP</h1>
            <p>Klik tombol di bawah untuk chat langsung dengan 3 Admin INA-PREDICT</p>
        </div>

        <!-- 3 ADMIN HORIZONTAL -->
        <div class="admins-container">
            <div class="admin-card" onclick="openWA('628976391786', 'Admin 1')">
                <div class="admin-avatar"><i class="fab fa-whatsapp"></i></div>
                <div class="admin-name">Admin 1 <span class="badge-online"></span></div>
                <div class="admin-role">Koordinator Lapangan</div>
                <div class="admin-platform"><i class="fab fa-whatsapp"></i> WhatsApp</div>
                <div class="admin-number">+62 897-6391-786</div>
                <div style="font-size:0.55rem; margin-top:12px; opacity:0.6;">Respons cepat untuk laporan darurat & koordinasi lapangan</div>
            </div>

            <div class="admin-card" onclick="openWA('6281315680425', 'Admin 2')">
                <div class="admin-avatar"><i class="fab fa-whatsapp"></i></div>
                <div class="admin-name">Admin 2 <span class="badge-online"></span></div>
                <div class="admin-role">Info & Diseminasi</div>
                <div class="admin-platform"><i class="fab fa-whatsapp"></i> WhatsApp</div>
                <div class="admin-number">+62 813-1568-0425</div>
                <div style="font-size:0.55rem; margin-top:12px; opacity:0.6;">Update info bencana, peringatan dini, dan koordinasi relawan</div>
            </div>

            <div class="admin-card" onclick="openWA('6285147119574', 'Admin 3')">
                <div class="admin-avatar"><i class="fab fa-whatsapp"></i><i class="fas fa-box" style="margin-left: 8px; font-size: 1.5rem;"></i></div>
                <div class="admin-name">Admin 3 <span class="badge-online"></span></div>
                <div class="admin-role">Logistik & Bantuan</div>
                <div class="admin-platform"><i class="fab fa-whatsapp"></i> WhatsApp</div>
                <div class="admin-number">+62 851-4711-9574</div>
                <div style="font-size:0.55rem; margin-top:12px; opacity:0.6;">Distribusi bantuan, donasi, dan kebutuhan logistik bencana</div>
            </div>
        </div>

        <!-- FORM LAPORAN -->
        <div class="form-card">
            <div class="card-header">
                <i class="fas fa-pen-alt"></i>
                <h3>📝 LAPORKAN KELUHAN / KEJADIAN BENCANA</h3>
            </div>
            <div class="info-badge">
                <p><i class="fab fa-whatsapp"></i> Isi form di bawah, lalu kirim. Laporan akan LANGSUNG terkirim ke 3 Admin via Fonnte (WhatsApp Gateway)!</p>
            </div>
            <form id="complaintForm">
                <div class="form-group">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-input" id="fullName" placeholder="Contoh: Ahmad Wijaya" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Nomor WhatsApp (Agar Admin bisa menghubungi balik)</label>
                    <input type="tel" class="form-input" id="phoneNumber" placeholder="Contoh: 081234567890" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Provinsi / Kabupaten / Kota</label>
                    <select class="form-select" id="regionSelect" required>
                        <option value="">Pilih Provinsi</option>
                        <option value="Aceh">Aceh</option><option value="Sumatera Utara">Sumatera Utara</option>
                        <option value="Sumatera Barat">Sumatera Barat</option><option value="Riau">Riau</option>
                        <option value="Jambi">Jambi</option><option value="Sumatera Selatan">Sumatera Selatan</option>
                        <option value="Bengkulu">Bengkulu</option><option value="Lampung">Lampung</option>
                        <option value="Kep. Bangka Belitung">Kep. Bangka Belitung</option><option value="Kepulauan Riau">Kepulauan Riau</option>
                        <option value="DKI Jakarta">DKI Jakarta</option><option value="Jawa Barat">Jawa Barat</option>
                        <option value="Jawa Tengah">Jawa Tengah</option><option value="DI Yogyakarta">DI Yogyakarta</option>
                        <option value="Jawa Timur">Jawa Timur</option><option value="Banten">Banten</option>
                        <option value="Bali">Bali</option><option value="NTB">NTB</option><option value="NTT">NTT</option>
                        <option value="Kalimantan Barat">Kalimantan Barat</option><option value="Kalimantan Tengah">Kalimantan Tengah</option>
                        <option value="Kalimantan Selatan">Kalimantan Selatan</option><option value="Kalimantan Timur">Kalimantan Timur</option>
                        <option value="Kalimantan Utara">Kalimantan Utara</option><option value="Sulawesi Utara">Sulawesi Utara</option>
                        <option value="Sulawesi Tengah">Sulawesi Tengah</option><option value="Sulawesi Selatan">Sulawesi Selatan</option>
                        <option value="Sulawesi Tenggara">Sulawesi Tenggara</option><option value="Sulawesi Barat">Sulawesi Barat</option>
                        <option value="Gorontalo">Gorontalo</option><option value="Maluku">Maluku</option>
                        <option value="Maluku Utara">Maluku Utara</option><option value="Papua">Papua</option>
                        <option value="Papua Barat">Papua Barat</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Jenis Laporan / Keluhan</label>
                    <select class="form-select" id="complaintType" required>
                        <option value="">Pilih Jenis</option>
                        <option value="Banjir">🌊 Banjir</option>
                        <option value="Tanah Longsor">⛰️ Tanah Longsor</option>
                        <option value="Gempa Bumi">🌍 Gempa Bumi</option>
                        <option value="Kebakaran Hutan">🔥 Kebakaran Hutan</option>
                        <option value="Angin Puting Beliung">💨 Angin Puting Beliung</option>
                        <option value="Kekeringan">🏜️ Kekeringan</option>
                        <option value="Infrastruktur Rusak">🏚️ Infrastruktur Rusak</option>
                        <option value="Bantuan Belum Datang">📦 Bantuan Belum Datang</option>
                        <option value="Lainnya">📝 Lainnya</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Deskripsi Kejadian / Keluhan</label>
                    <textarea class="form-textarea" id="complaintDesc" placeholder="Ceritakan kejadian secara detail..." required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Lokasi Detail (Alamat / Patokan)</label>
                    <input type="text" class="form-input" id="locationDetail" placeholder="Contoh: RT 02 RW 05, Kelurahan X, Kecamatan Y" required>
                </div>
                <button type="button" class="btn-submit" onclick="sendViaFonnte()">
                    <i class="fab fa-whatsapp"></i> KIRIM VIA FONNTE (WA OTOMATIS)
                </button>
            </form>
        </div>

        <!-- KONTAK BPBD -->
        <div class="government-card">
            <div class="card-header">
                <i class="fas fa-landmark"></i>
                <h3>📞 KONTAK BPBD PER PROVINSI (TINDAK LANJUT LANGSUNG)</h3>
            </div>
            <div class="government-grid" id="bpbdGovGrid"></div>
            <div style="margin-top: 16px; text-align: center; font-size: 0.55rem;">
                <i class="fas fa-phone"></i> Hubungi BPBD provinsi Anda untuk tindak lanjut cepat | Semua terintegrasi dengan 112
            </div>
        </div>

        <div style="text-align:center; font-size:0.45rem; opacity:0.5; margin-top:16px; padding:12px;">
            <i class="fab fa-whatsapp"></i> Laporan akan otomatis terkirim ke 3 Admin via Fonnte | Respon dalam 2x24 jam
        </div>
    </main>
</div>

<div id="detailModal" class="modal">
    <div class="modal-content">
        <div class="modal-header"><h3 id="modalTitle">Detail Informasi</h3><div class="close-modal" onclick="closeModal()"><i class="fas fa-times"></i></div></div>
        <div class="modal-body" id="modalBody"></div>
    </div>
</div>

<script>
function toggleTheme() {
    if(document.body.classList.contains('dark')) {
        document.body.classList.remove('dark');
        document.body.classList.add('light');
        localStorage.setItem('theme', 'light');
        showToast('🌞 Light mode aktif');
    } else {
        document.body.classList.remove('light');
        document.body.classList.add('dark');
        localStorage.setItem('theme', 'dark');
        showToast('🌙 Dark mode aktif');
    }
}
if(localStorage.getItem('theme') === 'light') {
    document.body.classList.remove('dark');
    document.body.classList.add('light');
}

// ========== FUNGSI OPEN WA DENGAN TEKS KEREN ==========
function openWA(phoneNumber, adminName) {
    let phone = phoneNumber.replace(/[^0-9]/g, '');
    if (!phone.startsWith('62')) phone = '62' + phone;
    
    // Ambil data dari form (jika sudah diisi)
    const name = document.getElementById('fullName')?.value.trim() || 'Belum diisi';
    const userPhone = document.getElementById('phoneNumber')?.value.trim() || 'Belum diisi';
    const region = document.getElementById('regionSelect')?.value || 'Belum diisi';
    const type = document.getElementById('complaintType')?.value || 'Belum diisi';
    
    // Teks WhatsApp yang lebih KEREN!
    const message = `🌟 *INA-PREDICT - LAPORAN BENCANA* 🌟

Halo *${adminName}*! 👋

Saya ingin melaporkan kejadian bencana/keluhan melalui sistem INA-PREDICT.

📋 *DATA PELAPOR:*
• Nama: ${name}
• Kontak: ${userPhone}
• Lokasi: ${region}
• Jenis: ${type}

⚠️ Mohon segera ditindaklanjuti.

Terima kasih. 🙏

---
📱 *Laporan otomatis dari website INA-PREDICT*
🆔 *ID Laporan:* ${new Date().getTime().toString().slice(-8)}`;
    
    const encodedMessage = encodeURIComponent(message);
    const url = `https://wa.me/${phone}?text=${encodedMessage}`;
    window.open(url, '_blank');
    showToast(`📱 Membuka chat WhatsApp dengan ${adminName} ✨`);
}

// ========== KONFIGURASI FONNTE ==========
const FONNTE_API_KEY = 'iSLQpBJxG3aZxn5eMuyg';

const adminNumbers = [
    '628976391786',
    '6281315680425',
    '6285147119574'
];

async function sendViaFonnte() {
    const name = document.getElementById('fullName').value.trim();
    const phone = document.getElementById('phoneNumber').value.trim();
    const region = document.getElementById('regionSelect').value;
    const type = document.getElementById('complaintType').value;
    const desc = document.getElementById('complaintDesc').value.trim();
    const location = document.getElementById('locationDetail').value.trim();

    if (!name || !phone || !region || !type || !desc || !location) {
        showToast('⚠️ Harap lengkapi semua data terlebih dahulu!');
        return;
    }

    const btn = document.querySelector('#complaintForm .btn-submit');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Mengirim via Fonnte...';

    const message = `*📢 LAPORAN BENCANA / KELUHAN BARU*

👤 *Nama:* ${name}
📞 *Kontak:* ${phone}
📍 *Lokasi:* ${region} - ${location}
⚠️ *Jenis:* ${type}
📝 *Deskripsi:*
${desc}

⏰ *Waktu Laporan:* ${new Date().toLocaleString('id-ID')}
🆔 *Sumber:* INA-PREDICT Early Warning System

---
*Tindak Lanjut:*
✅ Admin akan segera merespon
📞 Pastikan nomor Anda aktif
🔄 Laporan ini otomatis dari website INA-PREDICT`;

    let successCount = 0;

    for (const adminNumber of adminNumbers) {
        try {
            const formData = new FormData();
            formData.append('target', adminNumber);
            formData.append('message', message);
            
            const response = await fetch('https://api.fonnte.com/send', {
                method: 'POST',
                headers: {
                    'Authorization': FONNTE_API_KEY
                },
                body: formData
            });
            
            const result = await response.json();
            console.log(`Kirim ke ${adminNumber}:`, result);
            
            if (result.status === true) {
                successCount++;
            }
        } catch (err) {
            console.error(`Error kirim ke ${adminNumber}:`, err);
        }
    }
    
    if (successCount > 0) {
        document.getElementById('fullName').value = '';
        document.getElementById('phoneNumber').value = '';
        document.getElementById('regionSelect').value = '';
        document.getElementById('complaintType').value = '';
        document.getElementById('complaintDesc').value = '';
        document.getElementById('locationDetail').value = '';
        
        showToast(`✅ Laporan terkirim ke ${successCount} Admin via Fonnte! Notifikasi akan masuk ke WhatsApp mereka.`);
        
        if (phone && phone.length > 8) {
            try {
                const userPhone = phone.replace(/[^0-9]/g, '');
                const userPhoneFormatted = userPhone.startsWith('62') ? userPhone : '62' + userPhone;
                const confirmMessage = `*Terima kasih, ${name}!*\n\nLaporan Anda telah kami terima dan akan segera ditindaklanjuti oleh tim INA-PREDICT.\n\n📋 *Ringkasan Laporan:*\nJenis: ${type}\nLokasi: ${location}\n\n⏰ Waktu: ${new Date().toLocaleString('id-ID')}\n\nAdmin akan menghubungi Anda segera. Tetap waspada dan utamakan keselamatan!`;
                
                const confirmFormData = new FormData();
                confirmFormData.append('target', userPhoneFormatted);
                confirmFormData.append('message', confirmMessage);
                
                await fetch('https://api.fonnte.com/send', {
                    method: 'POST',
                    headers: { 'Authorization': FONNTE_API_KEY },
                    body: confirmFormData
                });
            } catch(e) {
                console.log('Notifikasi ke pengirim gagal');
            }
        }
    } else {
        showToast('❌ Gagal mengirim laporan. Cek koneksi dan token Fonnte!');
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="fab fa-whatsapp"></i> KIRIM VIA FONNTE (WA OTOMATIS)';
}

const bpbdGovData = [
    { province: "Aceh", number: "0651-23232" },{ province: "Sumatera Utara", number: "061-4567890" },
    { province: "Sumatera Barat", number: "0751-12345" },{ province: "Riau", number: "0761-23456" },
    { province: "Jambi", number: "0741-34567" },{ province: "Sumatera Selatan", number: "0711-45678" },
    { province: "Bengkulu", number: "0736-56789" },{ province: "Lampung", number: "0721-67890" },
    { province: "Kep. Bangka Belitung", number: "0717-78901" },{ province: "Kepulauan Riau", number: "0778-89012" },
    { province: "DKI Jakarta", number: "021-3901234" },{ province: "Jawa Barat", number: "022-4234567" },
    { province: "Jawa Tengah", number: "024-8345678" },{ province: "DI Yogyakarta", number: "0274-512345" },
    { province: "Jawa Timur", number: "031-5345678" },{ province: "Banten", number: "0254-234567" },
    { province: "Bali", number: "0361-234567" },{ province: "NTB", number: "0370-634567" },
    { province: "NTT", number: "0380-434567" },{ province: "Kalimantan Barat", number: "0561-734567" },
    { province: "Kalimantan Tengah", number: "0536-334567" },{ province: "Kalimantan Selatan", number: "0511-3345678" },
    { province: "Kalimantan Timur", number: "0541-7345678" },{ province: "Kalimantan Utara", number: "0552-234567" },
    { province: "Sulawesi Utara", number: "0431-854567" },{ province: "Sulawesi Tengah", number: "0451-454567" },
    { province: "Sulawesi Selatan", number: "0411-854567" },{ province: "Sulawesi Tenggara", number: "0401-354567" },
    { province: "Sulawesi Barat", number: "0426-724567" },{ province: "Gorontalo", number: "0435-124567" },
    { province: "Maluku", number: "0911-324567" },{ province: "Maluku Utara", number: "0921-424567" },
    { province: "Papua", number: "0967-524567" },{ province: "Papua Barat", number: "0986-624567" }
];

function renderBPBDGov() {
    document.getElementById('bpbdGovGrid').innerHTML = bpbdGovData.map(g => `
        <div class="government-card-item" onclick="showDetail('BPBD ${g.province}', '📞 NOMOR: ${g.number}\\n📱 HOTLINE DARURAT: 112\\n📍 PROVINSI: ${g.province}\\n\\n📝 Layanan: Penanggulangan bencana daerah, evakuasi, logistik, dan koordinasi bantuan.\\n\\n⚠️ Untuk keadaan darurat, selalu hubungi 112 terlebih dahulu.')">
            <div class="gov-name"><i class="fas fa-building"></i> ${g.province}</div>
            <div>📞 ${g.number}</div>
            <div class="gov-number">🚨 Hotline: 112</div>
        </div>
    `).join('');
}

function showDetail(title, content) {
    document.getElementById('modalTitle').innerHTML = title;
    document.getElementById('modalBody').innerHTML = `
        <div class="detail-card">${content.replace(/\n/g, '<br>')}</div>
        <button class="btn-submit" onclick="closeModal()" style="background: linear-gradient(135deg,#2b6e4e,#3d9b6d);"><i class="fas fa-check"></i> Tutup</button>
    `;
    document.getElementById('detailModal').style.display = 'flex';
}

function closeModal() { document.getElementById('detailModal').style.display = 'none'; }

function showToast(msg) { 
    const t = document.createElement('div'); 
    t.className = 'toast'; 
    t.innerHTML = `<i class="fab fa-whatsapp"></i> ${msg}`; 
    document.body.appendChild(t); 
    setTimeout(() => t.remove(), 3000); 
}

document.getElementById('lastUpdate').innerHTML = new Date().toLocaleString('id-ID');
renderBPBDGov();
</script>
</body>
</html>"""
components.html(html_content, height=1200, scrolling=True)
