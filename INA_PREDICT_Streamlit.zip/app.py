
import streamlit as st

st.set_page_config(page_title="INA-PREDICT", layout="wide")

st.title("INA-PREDICT")
st.write("Aplikasi hasil konversi dari project HTML ke struktur multi-page Streamlit.")
st.sidebar.success("Pilih halaman dari menu Pages di sidebar.")
